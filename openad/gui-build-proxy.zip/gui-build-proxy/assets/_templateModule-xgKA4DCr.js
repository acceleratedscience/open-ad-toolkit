import{d as e,u as t,a as s,b as a}from"./index-DRw_S7Oy.js";const n=e({__name:"_templateModule",setup(o){return t(),s(),a(),(u,r)=>"ABC"}});export{n as default};
