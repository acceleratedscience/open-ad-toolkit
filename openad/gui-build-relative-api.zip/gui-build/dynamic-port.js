// const url = window.location
// console.log('$$$', window.location.pathname, window.location)
// const proxyMatch = url.match(/\/proxy\//)
// if (proxyMatch) {
//     // const proxyPortMatch = url.match(/\/proxy\/\d{4}\//)
// }